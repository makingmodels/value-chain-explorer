# Alpha-X Value Chain Explorer

**Institutional-grade value chain analysis powered by dynamic hypergraph neural networks, distributional reinforcement learning, causal discovery, and variational Bayesian inference.**

---

## Architecture Overview

Alpha-X treats equity value chains as **dynamic latent hypergraphs** H(t) = (V, E, X_V, X_E):

| Component | Method | Purpose |
|---|---|---|
| **Graph Representation** | Dynamic Hypergraph Neural Network (DHGNN) | Captures set-based relationships (hyperedges) beyond pairwise links |
| **Latent Structure** | Variational Graph Autoencoder (VGAE) | Learns hidden market regimes: A_lat(t) = σ(Z_t Z_t^T) |
| **Portfolio Optimisation** | Truncated Quantile Critics (TQC) | Distributional RL — optimises return distribution, not just mean |
| **Causal Discovery** | PC-Algorithm + Do-Calculus | Filters spurious correlations; validates causal links |
| **Risk Estimation** | Bayesian Model with Student-t Likelihood + Normalizing Flows | Fat-tail aware CVaR in milliseconds (vs minutes for MCMC) |
| **Alternative Data** | Marketaux (news), SerpApi (patents), FinBERT (sentiment) | Multi-modal 47-dim node feature vector |

### Dual Adjacency Structure
```
A_total(t) = α · A_phy(t) + (1 - α) · A_lat(t)
```
- **A_phy**: Physical supply chain links (explicit, from filings/news)
- **A_lat**: Latent adjacency learned via VGAE (captures hidden regimes like meme-stock co-movement)

### TQC Portfolio Policy
The actor outputs portfolio weights via a Dirichlet distribution:
```
π(a_t | s_t) = Dirichlet(α_1(s_t), ..., α_n(s_t))
```
The critic models **25 quantiles** of the return distribution. Only the bottom N_d = 5 quantiles are used for the actor gradient, making the policy **pessimistic** (tail-risk aware).

---

## Application Structure

```
app/
├── app.py                      # Entrypoint, nav, view routing
├── .streamlit/config.toml      # Dark theme config
├── views/
│   ├── map_view.py             # Screen A: Value Chain Explorer
│   ├── analyze_view.py         # Screen B: Alpha & Risk Lens
│   └── act_view.py             # Screen C: Portfolio Construction
├── components/
│   ├── theme.py                # Global CSS, colour palette, pills
│   ├── metrics.py              # KPI strip (Sharpe, Max DD, CVaR)
│   ├── graph_canvas.py         # Hypergraph renderer (streamlit-agraph)
│   └── panels.py               # Company detail, distributions, causal panels
└── services/
    ├── data_models.py          # Pydantic models (Node, Hyperedge, CausalEdge, etc.)
    ├── alpha_backend.py        # Backend orchestrator with realistic mocks
    ├── market_data.py          # yfinance wrapper
    ├── marketaux_client.py     # Marketaux news/sentiment API
    ├── patents_client.py       # SerpApi Google Patents
    ├── perplexity_client.py    # Perplexity API (optional NLP enrichment)
    └── claude_client.py        # Claude API (optional thesis generation)
```

### Three Screens

1. **Map** — Visual value chain explorer. Pan/zoom hypergraph, toggle physical supply and latent regime layers, click nodes for detail panels.
2. **Analyze** — Alpha Map (nodes by expected return), Tail-Risk Map (nodes by CVaR), Causal Graph (PC-algorithm DAG with Do-Calculus validation).
3. **Act** — Portfolio construction with TQC-suggested vs benchmark allocations, risk controls, hyperedge tilting, factor exposure analysis.

---

## Setup

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure API Keys (Optional)

Create `.streamlit/secrets.toml` in the `app/` directory:
```toml
MARKETAUX_API_KEY = "your-marketaux-key"
SERPAPI_API_KEY = "your-serpapi-key"
PERPLEXITY_API_KEY = "your-perplexity-key"
CLAUDE_API_KEY = "your-claude-api-key"
```

**The app works without any API keys** — all external data sources have mock fallbacks. Keys enable live data:

| Key | Source | What It Enables |
|---|---|---|
| `MARKETAUX_API_KEY` | [Marketaux](https://www.marketaux.com/) | Real-time news sentiment |
| `SERPAPI_API_KEY` | [SerpApi](https://serpapi.com/) | Google Patents data for Q_patent scoring |
| `PERPLEXITY_API_KEY` | [Perplexity](https://docs.perplexity.ai/) | AI-generated cluster explanations |
| `CLAUDE_API_KEY` | [Anthropic](https://docs.anthropic.com/) | Investment thesis generation |

**yfinance** requires no API key and makes real calls by default.

### 3. Run
```bash
cd app
streamlit run app.py
```

---

## Where Real Models Plug In

Each mock in `alpha_backend.py` is annotated with `# TODO: PLUG` showing exactly what replaces it:

| Mock Function | Real Implementation |
|---|---|
| `get_valuechain()` | DHGNN forward pass → VGAE latent structure → community detection |
| `get_causal_graph()` | PC-Algorithm + Do-Calculus validation (CausalNex) |
| `get_portfolio_suggestion()` | TQC actor network `π(a_t\|s_t) = Dirichlet(...)` |
| Correlation heatmap | `Σ_ij = corr(h_i^DHGNN, h_j^DHGNN) · exp(-d_H(i,j))` |
| Factor exposures | Hierarchical Bayesian model β_i,k with Student-t likelihood |

---

## References

- Feng et al. (2019) — *Hypergraph Neural Networks*
- Kurutach et al. (2021) — *Truncated Quantile Critics*
- Spirtes et al. (2000) — *PC-Algorithm*
- Pearl (2009) — *Do-Calculus*
- Rezende & Mohamed (2015) — *Normalizing Flows*
- Gu et al. (2020) — *Empirical Asset Pricing via ML*
